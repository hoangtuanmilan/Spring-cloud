package jmaster.io.accountservice;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountserviceApplicationTests {

//	@Test
//	void contextLoads() {
//	}
}
